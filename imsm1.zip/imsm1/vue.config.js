module.exports = {
  productionSourceMap: false
};
