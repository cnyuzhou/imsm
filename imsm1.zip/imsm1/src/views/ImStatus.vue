<template>
  <div>
    <div style="fontSize:200%;fontWeight:bolder;color:blue;">工业设备工作状态实时监控</div>
    <hr/>
    <div id="chartPie" style="width:100%;height:300%;"></div>
    <div id="chartBar" style="width:100%;height:300%;"></div>
  </div>
</template>
 
<script>
export default {
  name: "charPie",
  data() {
    return {
      names: { "1": "运行", "0": "停机", "-1": "故障" },
      colors: { "1": "green", "0": "black", "-1": "red" }
    };
  },
  methods: {
    drawPieChart() {
      //charPie
      this.chartPie = this.$echarts.init(document.getElementById("chartPie"));
      this.chartPie.setOption({
        animation: false,
        title: [
          {
            subtext: "一号工业设备",
            left: "16.67%",
            top: "75%",
            textAlign: "center",
            subtextStyle: {
              fontSize: 20,
              fontWeight: "bolder",
              color: "blue"
            }
          },
          {
            subtext: "二号工业设备",
            left: "50%",
            top: "75%",
            textAlign: "center",
            subtextStyle: {
              fontSize: 20,
              fontWeight: "bolder",
              color: "blue"
            }
          },
          {
            subtext: "三号工业设备",
            left: "83.33%",
            top: "75%",
            textAlign: "center",
            subtextStyle: {
              fontSize: 20,
              fontWeight: "bolder",
              color: "blue"
            }
          }
        ],
        //具体点击某一项触发的样式内容
        tooltip: {
          formatter: "{b}"
        },
        //左上侧分类条形符
        legend: {
          orient: "horizontal",
          left: "auto",
          top: "3%",
          data: Object.values(this.names)
        },
        //饼状图类型以及数据源
        series: [
          {
            type: "pie",
            radius: "50%",
            center: ["50%", "50%"],
            data: [],
            hoverAnimation: true,
            label: {
              position: "outer",
              alignTo: "none",
              bleedMargin: 5,
              normal: {
                position: "inner",
                show: false
              }
            },
            left: 0,
            right: "66.6667%",
            top: 0,
            bottom: 0,
            itemStyle: {
              shadowColor: "rgba(0, 0, 0, 0.5)",
              shadowBlur: 10
            }
          },
          {
            type: "pie",
            radius: "50%",
            center: ["50%", "50%"],
            data: [],
            hoverAnimation: true,
            label: {
              position: "outer",
              alignTo: "labelLine",
              bleedMargin: 5,
              normal: {
                position: "inner",
                show: false
              }
            },
            left: "33.3333%",
            right: "33.3333%",
            top: 0,
            bottom: 0,
            itemStyle: {
              shadowColor: "rgba(0, 0, 0, 0.5)",
              shadowBlur: 10
            }
          },
          {
            type: "pie",
            radius: "50%",
            center: ["50%", "50%"],
            data: [],
            hoverAnimation: true,
            label: {
              position: "outer",
              alignTo: "edge",
              margin: 20,
              normal: {
                position: "inner",
                show: false
              }
            },
            left: "66.6667%",
            right: 0,
            top: 0,
            bottom: 0,
            itemStyle: {
              shadowColor: "rgba(0, 0, 0, 0.5)",
              shadowBlur: 10
            }
          }
        ]
      });
    },

    drawBarChart() {
      //setOption
      this.chartBar = this.$echarts.init(document.getElementById("chartBar"));
      this.chartBar.setOption({
        animation: false,
        tooltip: {},
        title: {},
        legend: {},
        dataZoom: [
          {
            type: "slider",
            filterMode: "weakFilter",
            showDataShadow: false,
            top: 250,
            height: 10,
            start: 0,
            end: 100,
            borderColor: "transparent",
            backgroundColor: "#e2e2e2",
            handleIcon:
              "M10.7,11.9H9.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4h1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7v-1.2h6.6z M13.3,22H6.7v-1.2h6.6z M13.3,19.6H6.7v-1.2h6.6z", // jshint ignore:line
            handleSize: 20,
            handleStyle: {
              shadowBlur: 6,
              shadowOffsetX: 1,
              shadowOffsetY: 2,
              shadowColor: "#aaa"
            },
            labelFormatter: ""
          },
          {
            type: "inside",
            filterMode: "weakFilter"
          }
        ],
        xAxis: {
          type: "time",
          //min: 0,
          scale: true
          // axisLabel: {
          //     formatter: function(val) {
          //         return Math.max(0, val - startTime);
          //     }
          // }
        },
        yAxis: {
          data: []
        },
        series: []
      });
    },

    //动态获取饼状图的数据
    async initDataPie() {
      var self = this;
      var res = await this.$axios.get(
        self.GLOBAL.baseURL + "/imstatussequence/getCurrentStatus"
      );
      //console.log(res.data);
      var getData = [];
      //先进行赋值
      for (let i = 0; i < res.data.length; i++) {
        var obj = new Object();
        obj.name = this.names[res.data[i].statusid];
        obj.value = res.data[i].statusid;
        obj.itemStyle = {
          normal: { color: this.colors[res.data[i].statusid] }
        };
        getData[i] = obj;
      }
      //console.log(getData);

      this.chartPie.setOption({
        animation: false,
        series: [
          {
            data: [getData[0]]
          },
          {
            data: [getData[1]]
          },
          {
            data: [getData[2]]
          }
        ]
      });
    },

    //动态获取柱状图的数据
    async initDataBar() {
      var self = this;
      //charBar
      //var dataCount = 100; // 测试数据条数
      var startTime = 99999999999999999999;
      var categories = ["一号工业设备", "二号工业设备", "三号工业设备"].reverse();

      function renderItem(params, api) {
        var categoryIndex = api.value(0);
        var start = api.coord([api.value(1), categoryIndex]);
        var end = api.coord([api.value(2), categoryIndex]);
        var height = api.size([0, 1])[1] * 0.8;

        return {
          type: "rect",
          shape: self.$echarts.graphic.clipRectByRect(
            {
              x: start[0],
              y: start[1] - height / 2,
              width: end[0] - start[0],
              height: height
            },
            {
              x: params.coordSys.x,
              y: params.coordSys.y,
              width: params.coordSys.width,
              height: params.coordSys.height
            }
          ),
          style: api.style()
        };
      }

      var res = await this.$axios.get(
        self.GLOBAL.baseURL + "/imstatussequence/getDuringStatus"
      );
      //console.log(res.data);
      var getData = [];
      var timestamp1 = 0,
        timestamp2 = 0;
      var imid1 = "";
      //先进行赋值
      for (let i = 0; i < res.data.length; i++) {
        var obj = new Object();
        obj.name = res.data[i].statusname;
        timestamp1 = Date.parse(
          new Date(res.data[i].logtime.replace(/T/g, "/") + " UTC+8:00")
        );
        startTime = startTime < timestamp1 ? startTime : timestamp1;
        imid1 = res.data[i].imid;
        timestamp2 =
          i + 1 == res.data.length || imid1 != res.data[i + 1].imid
            ? Date.parse(new Date())
            : Date.parse(
                new Date(
                  res.data[i + 1].logtime.replace(/T/g, "/") + " UTC+8:00"
                )
              );
        obj.value = [];
        obj.value[0] = res.data[i].imname;
        obj.value[1] = timestamp1;
        obj.value[2] = timestamp2;
        obj.value[3] = timestamp2 - timestamp1;
        obj.itemStyle = {
          normal: { color: this.colors[res.data[i].statusid] }
        };
        getData[i] = obj;
      }
      //console.log(getData);

      //setOption
      this.chartBar.setOption({
        animation: false,
        tooltip: {
          formatter: function(params) {
            //console.log(params)
            return (
              params.marker +
              params.name +
              ": " +
              self.GLOBAL.formatDate(
                new Date(params.value[1]),
                "yyyy-MM-dd hh:mm:ss"
              ) +
              " ~ " +
              self.GLOBAL.formatDate(
                new Date(params.value[2]),
                "yyyy-MM-dd hh:mm:ss"
              ) +
              " [ " +
              params.value[3] / 1000 +
              " 秒 ]"
            );
          }
        },
        title: {},
        legend: {},
        grid: {
          height: 150
        },
        xAxis: {
          type: "time",
          min: startTime,
          scale: true
          // axisLabel: {
          //     formatter: function(val) {
          //         return Math.max(0, val - startTime);
          //     }
          // }
        },
        yAxis: {
          data: categories
        },
        series: [
          {
            type: "custom",
            renderItem: renderItem,
            itemStyle: {
              normal: {
                opacity: 0.1
              }
            },
            encode: {
              x: [1, 2],
              y: 0
            },
            data: getData
          }
        ]
      });
    },

    //websocket
    initWebSocket() {
      var self = this;
      //初始化weosocket
      let ws = new WebSocket(this.GLOBAL.wsuri); //这里new 一个WebSocket对象将连接地址传入（这个连接地址很重要，很多情况连接不上就是连接地址没用写对）
      ws.onopen = () => {
        // Web Socket 已连接上，使用 send() 方法发送数据
        //console.log("数据发送中...");
        //ws.send("Holle");
        //console.log("数据发送完成");
      };
      ws.onmessage = evt => {
        //console.log("数据已接收..." + evt.data);
        //先进行赋值
        var getData = [];
        var jsonobj = JSON.parse(evt.data);
        //通过msgid来区分消息标示
        //console.log(jsonobj.msgid);
        switch (jsonobj.msgid) {
          case 1: {
            for (var i in jsonobj.msg) {
              var obj = new Object();
              obj.name = this.names[jsonobj.msg[i].statusid];
              obj.value = jsonobj.msg[i].statusid;
              obj.itemStyle = {
                normal: { color: this.colors[jsonobj.msg[i].statusid] }
              };
              getData[i] = obj;
            }
            //console.log(this.names[jsonobj.msg[i].statusid]);

            this.chartPie.setOption({
              animation: false,
              series: [
                {
                  data: [getData[0]]
                },
                {
                  data: [getData[1]]
                },
                {
                  data: [getData[2]]
                }
              ]
            });
            break;
          }
          case 2: {
            var startTime = 99999999999999999999;
            var categories = [
              "一号工业设备",
              "二号工业设备",
              "三号工业设备"
            ].reverse();

            var timestamp1 = 0,
              timestamp2 = 0;
            var imid1 = "";
            //先进行赋值
            for (let i = 0; i < jsonobj.msg.length; i++) {
              var obj2 = new Object();
              obj2.name = jsonobj.msg[i].statusname;
              timestamp1 = Date.parse(new Date(jsonobj.msg[i].logtime));
              startTime = startTime < timestamp1 ? startTime : timestamp1;
              imid1 = jsonobj.msg[i].imid;
              timestamp2 =
                i + 1 == jsonobj.msg.length || imid1 != jsonobj.msg[i + 1].imid
                  ? Date.parse(new Date())
                  : Date.parse(new Date(jsonobj.msg[i + 1].logtime));
              obj2.value = [];
              obj2.value[0] = jsonobj.msg[i].imname;
              obj2.value[1] = timestamp1;
              obj2.value[2] = timestamp2;
              obj2.value[3] = timestamp2 - timestamp1;
              obj2.itemStyle = {
                normal: { color: this.colors[jsonobj.msg[i].statusid] }
              };
              getData[i] = obj2;
            }
            //console.log(getData);

            //setOption
            this.chartBar.setOption({
              animation: false,
              tooltip: {
                formatter: function(params) {
                  //console.log(params)
                  return (
                    params.marker +
                    params.name +
                    ": " +
                    self.GLOBAL.formatDate(
                      new Date(params.value[1]),
                      "yyyy-MM-dd hh:mm:ss"
                    ) +
                    " ~ " +
                    self.GLOBAL.formatDate(
                      new Date(params.value[2]),
                      "yyyy-MM-dd hh:mm:ss"
                    ) +
                    " [ " +
                    params.value[3] / 1000 +
                    " 秒 ]"
                  );
                }
              },
              title: {},
              legend: {},
              grid: {
                height: 150
              },
              xAxis: {
                type: "time",
                min: startTime,
                scale: true
                // axisLabel: {
                //     formatter: function(val) {
                //         return Math.max(0, val - startTime);
                //     }
                // }
              },
              yAxis: {
                data: categories
              },
              series: [
                {
                  type: "custom",
                  renderItem: this.renderItem,
                  itemStyle: {
                    normal: {
                      opacity: 0.8
                    }
                  },
                  encode: {
                    x: [1, 2],
                    y: 0
                  },
                  data: getData
                }
              ]
            });
            break;
          }
          default:
            break;
        }
      };

      ws.onclose = function() {
        // 关闭 websocket
        //console.log("连接已关闭...");
      };
      // 路由跳转时结束websocket链接
      this.$router.afterEach(function() {
        ws.close();
      });
    },

    renderItem(params, api) {
      var categoryIndex = api.value(0);
      var start = api.coord([api.value(1), categoryIndex]);
      var end = api.coord([api.value(2), categoryIndex]);
      var height = api.size([0, 1])[1] * 0.8;

      return {
        type: "rect",
        shape: this.$echarts.graphic.clipRectByRect(
          {
            x: start[0],
            y: start[1] - height / 2,
            width: end[0] - start[0],
            height: height
          },
          {
            x: params.coordSys.x,
            y: params.coordSys.y,
            width: params.coordSys.width,
            height: params.coordSys.height
          }
        ),
        style: api.style()
      };
    },
    drawCharts() {
      this.drawPieChart();
      this.drawBarChart();
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.initDataPie();
      this.initDataBar();
    });
    this.drawCharts();
    window.addEventListener("resize", () => {
      this.chartPie.resize();
      this.chartBar.resize();
    });
  },
  created() {
    //页面刚进入时开启长连接
    this.initWebSocket();
  }
};
</script>