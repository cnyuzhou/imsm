import Vue from "vue";
import VueRouter from "vue-router";
import ImStatus from "../views/ImStatus.vue";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "ImStatus",
    component: ImStatus
  }
];

const router = new VueRouter({
  routes
});

export default router;
