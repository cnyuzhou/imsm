package com.zhouxh.imsm;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
public class ImsmApplicationTests {
    @Autowired
    private WebApplicationContext webApplicationContext;

    private MockMvc mockMvc;

    @Autowired
    private StringRedisTemplate template;

    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(
                webApplicationContext).build();
    }

    @Test
    public void ImsmApiTest() throws Exception {
        String uri = "/api/imstatus/getAll";
        MvcResult mvcResult = this.mockMvc
                .perform(MockMvcRequestBuilders.get(uri))
                .andReturn();
        System.out.println("uri: " + uri + ": " + mvcResult.getResponse().getContentAsString());

        uri = "/api/imstatussequence/getAll";
        mvcResult = this.mockMvc
                .perform(MockMvcRequestBuilders.get(uri))
                .andReturn();// 获取返回结果
        System.out.println("uri: " + uri + ": " + mvcResult.getResponse().getContentAsString());

        uri = "/api/imstatussequence/getDuringStatus";
        mvcResult = this.mockMvc
                .perform(MockMvcRequestBuilders.get(uri))
                .andReturn();// 获取返回结果
        System.out.println("uri: " + uri + ": " + mvcResult.getResponse().getContentAsString());

        //redis test
        this.template.opsForValue().append("mvcResult", mvcResult.getResponse().getContentAsString());
        System.out.println(template.opsForValue().get("mvcResult"));
        //this.template.opsForValue().getOperations().delete("mvcResult");

    }
}
