package com.zhouxh.imsm.controller;

import com.alibaba.fastjson.JSON;
import com.zhouxh.imsm.service.ImStatusSequenceService;
import com.zhouxh.imsm.websocket.ImsmWebSocket;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.concurrent.CopyOnWriteArraySet;

@Component
@EnableScheduling
public class ImsmTimeTaskController {
    @Autowired
    private ImStatusSequenceService imStatusSequenceService;
    private String msg1, msg2;

    @Scheduled(cron = "0/1 * * * * ?")
    public void test() {
        //System.err.println("*********   定时任务执行   **************");
        CopyOnWriteArraySet<ImsmWebSocket> webSocketSet =
                ImsmWebSocket.getWebSocketSet();
        int i = 0;
        msg1 = "{\"msgid\":1,\"msg\":" + JSON.toJSONString(imStatusSequenceService.getCurrentStatus()) + "}";
        msg2 = "{\"msgid\":2,\"msg\":" + JSON.toJSONString(imStatusSequenceService.getDuringStatus()) + "}";
        webSocketSet.forEach(c -> {
            try {
                c.sendMessage(msg1);
                c.sendMessage(msg2);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        //System.err.println("/n 定时任务完成.......");
    }
}
