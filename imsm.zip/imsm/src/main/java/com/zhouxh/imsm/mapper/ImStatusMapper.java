package com.zhouxh.imsm.mapper;

import com.zhouxh.imsm.model.ImStatus;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface ImStatusMapper {
    int deleteByPrimaryKey(Integer imid);

    int insert(ImStatus record);

    int insertSelective(ImStatus record);

    ImStatus selectByPrimaryKey(Integer imid);

    int updateByPrimaryKeySelective(ImStatus record);

    int updateByPrimaryKey(ImStatus record);

    @Select("SELECT * FROM im_status order by imid")
    List<ImStatus> getAll();
}