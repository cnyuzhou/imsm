package com.zhouxh.imsm.service.impl;

import com.zhouxh.imsm.mapper.ImStatusMapper;
import com.zhouxh.imsm.model.ImStatus;
import com.zhouxh.imsm.service.ImStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ImStatusServiceImpl implements ImStatusService {
    @Autowired
    private ImStatusMapper mapper;

    @Override
    public List<ImStatus> getAll() {
        return mapper.getAll();
    }
}
