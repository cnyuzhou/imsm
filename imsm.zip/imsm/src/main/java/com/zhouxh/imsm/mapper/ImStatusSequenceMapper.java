package com.zhouxh.imsm.mapper;

import com.zhouxh.imsm.model.ImStatusSequence;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

public interface ImStatusSequenceMapper {
    int deleteByPrimaryKey(Long sequenceid);

    int insert(ImStatusSequence record);

    int insertSelective(ImStatusSequence record);

    ImStatusSequence selectByPrimaryKey(Long sequenceid);

    int updateByPrimaryKeySelective(ImStatusSequence record);

    int updateByPrimaryKey(ImStatusSequence record);

    @Select("SELECT * FROM im_status_sequence order by imid,sequenceid desc")
    List<ImStatusSequence> getAll();

    @Select("select imid,statusid from (\n" +
            "SELECT a.*,\n" +
            "   IF(@imid = imid, @RN := @RN + 1, @RN := 1) AS rn,\n" +
            "   @imid := imid AS imid2\n" +
            "FROM im_status_sequence a, (SELECT @imid := '', @RN := 0) b\n" +
            "ORDER BY a.imid asc,a.sequenceid desc) c\n" +
            "where rn=1 order by imid;\n")
    List<Map<String, Object>> getCurrentStatus();

    @Select("SELECT b.imid,b.imname,c.statusid,c.statusname,c.isvalid,a.logtime \n" +
            "FROM (select s2.* \n" +
            "from (select\n" +
            "if( s1.imid = @imid, @rank := @rank + 1, @rank := 1 ) as rank,\n" +
            "@imid := imid as tmp_imid,\n" +
            "s1.imid,s1.statusid,s1.logtime \n" +
            "from\n" +
            "( select * from im_status_sequence order by imid, logtime desc ) s1,\n" +
            "( select @imid := null, @rank := 1 ) tmp \n" +
            ") s2 \n" +
            "where s2.rank <= 10) a,dim_imid b,dim_statusid c \n" +
            "where a.imid=b.imid and a.statusid=c.statusid\n" +
            "order by b.imid,a.logtime")
    List<Map<String, Object>> getDuringStatus();
}