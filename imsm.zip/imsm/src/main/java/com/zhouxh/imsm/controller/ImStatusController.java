package com.zhouxh.imsm.controller;

import com.zhouxh.imsm.model.ImStatus;
import com.zhouxh.imsm.service.ImStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/imstatus")
public class ImStatusController {
    @Autowired
    private ImStatusService service;

    @GetMapping("getAll")
    public List<ImStatus> getAll() {
        return service.getAll();
    }
}
