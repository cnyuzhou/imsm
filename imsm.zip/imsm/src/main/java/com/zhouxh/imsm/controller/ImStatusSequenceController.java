package com.zhouxh.imsm.controller;

import com.zhouxh.imsm.model.ImStatusSequence;
import com.zhouxh.imsm.service.ImStatusSequenceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/imstatussequence")
public class ImStatusSequenceController {
    @Autowired
    private ImStatusSequenceService service;

    @GetMapping("getAll")
    public List<ImStatusSequence> getAll() {
        return service.getAll();
    }

    @GetMapping("getCurrentStatus")
    public List<Map<String, Object>> getCurrentStatus() {
        return service.getCurrentStatus();
    }

    @GetMapping("getDuringStatus")
    public List<Map<String, Object>> getDuringStatus() {
        return service.getDuringStatus();
    }
}
