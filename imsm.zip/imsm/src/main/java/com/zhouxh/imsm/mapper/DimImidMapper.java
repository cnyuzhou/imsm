package com.zhouxh.imsm.mapper;

import com.zhouxh.imsm.model.DimImid;

public interface DimImidMapper {
    int deleteByPrimaryKey(Integer imid);

    int insert(DimImid record);

    int insertSelective(DimImid record);

    DimImid selectByPrimaryKey(Integer imid);

    int updateByPrimaryKeySelective(DimImid record);

    int updateByPrimaryKeyWithBLOBs(DimImid record);

    int updateByPrimaryKey(DimImid record);
}