package com.zhouxh.imsm.service;

import com.zhouxh.imsm.model.ImStatusSequence;

import java.util.List;
import java.util.Map;

public interface ImStatusSequenceService {
    public List<ImStatusSequence> getAll();

    public List<Map<String, Object>> getCurrentStatus();

    public List<Map<String, Object>> getDuringStatus();
}
