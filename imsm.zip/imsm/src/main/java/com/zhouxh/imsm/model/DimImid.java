package com.zhouxh.imsm.model;

public class DimImid {
    private Integer imid;

    private String imname;

    private Integer isvalid;

    private String memo;

    public Integer getImid() {
        return imid;
    }

    public void setImid(Integer imid) {
        this.imid = imid;
    }

    public String getImname() {
        return imname;
    }

    public void setImname(String imname) {
        this.imname = imname == null ? null : imname.trim();
    }

    public Integer getIsvalid() {
        return isvalid;
    }

    public void setIsvalid(Integer isvalid) {
        this.isvalid = isvalid;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo == null ? null : memo.trim();
    }
}