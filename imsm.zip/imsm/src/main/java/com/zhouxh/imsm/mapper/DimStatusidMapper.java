package com.zhouxh.imsm.mapper;

import com.zhouxh.imsm.model.DimStatusid;

public interface DimStatusidMapper {
    int deleteByPrimaryKey(Integer statusid);

    int insert(DimStatusid record);

    int insertSelective(DimStatusid record);

    DimStatusid selectByPrimaryKey(Integer statusid);

    int updateByPrimaryKeySelective(DimStatusid record);

    int updateByPrimaryKey(DimStatusid record);
}