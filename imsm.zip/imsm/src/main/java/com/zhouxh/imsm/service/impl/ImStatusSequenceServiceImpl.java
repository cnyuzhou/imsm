package com.zhouxh.imsm.service.impl;

import com.zhouxh.imsm.mapper.ImStatusSequenceMapper;
import com.zhouxh.imsm.model.ImStatusSequence;
import com.zhouxh.imsm.service.ImStatusSequenceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class ImStatusSequenceServiceImpl implements ImStatusSequenceService {
    @Autowired
    private ImStatusSequenceMapper mapper;

    @Override
    public List<ImStatusSequence> getAll() {
        return mapper.getAll();
    }

    @Override
    public List<Map<String, Object>> getCurrentStatus() {
        return mapper.getCurrentStatus();
    }

    @Override
    public List<Map<String, Object>> getDuringStatus() {
        return mapper.getDuringStatus();
    }
}
