package com.zhouxh.imsm.service;

import com.zhouxh.imsm.model.ImStatus;

import java.util.List;

public interface ImStatusService {
    public List<ImStatus> getAll();
}
