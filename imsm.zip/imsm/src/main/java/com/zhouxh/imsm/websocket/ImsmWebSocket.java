package com.zhouxh.imsm.websocket;

import com.zhouxh.imsm.service.ImStatusService;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.concurrent.CopyOnWriteArraySet;

@ServerEndpoint(value = "/websocket")  //这里是前端访问地址时需要带的。
@Component
public class ImsmWebSocket {

    public static CopyOnWriteArraySet<ImsmWebSocket> getWebSocketSet() {
        return webSocketSet;
    }

    public static void setWebSocketSet(CopyOnWriteArraySet<ImsmWebSocket> webSocketSet) {
        ImsmWebSocket.webSocketSet = webSocketSet;
    }

    private static CopyOnWriteArraySet<ImsmWebSocket> webSocketSet = new CopyOnWriteArraySet<ImsmWebSocket>();

    //private volatile static List<Session> sessions = Collections.synchronizedList(new ArrayList());
    private Session session;

    private static int linkCount = 0;

    /**
     * 连接建立成功调用的方法
     */
    @OnOpen
    public void onOpen(Session session) {
        //System.out.println("-------------有新的客户端连接----------");
        this.session = session;
        webSocketSet.add(this);
        this.linkCount++;
    }

    /**
     * 连接关闭调用的方法
     */
    @OnClose
    public void onClose() {
        //System.out.println("有一连接关闭");
        this.linkCount--;
        webSocketSet.remove(this);
    }

    /**
     * 给前台推消息
     *
     * @param message
     * @throws IOException
     */
    public void sendMessage(String message) throws IOException {
        //System.out.println("发送消息：" + message);
        for (ImsmWebSocket item : webSocketSet) {
            if (item.session.isOpen()) {   //判断session是否是打开状态的，打开状态的才发。
                item.session.getBasicRemote().sendText(message);
            }
        }


    }

    /**
     * 收到前端客户端消息后调用的方方法
     *
     * @param message 客户端发送过来的消息
     */
    @OnMessage
    public void onMessage(String message, Session session) {
        try {
            sendMessage(message);
        } catch (
                Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 发生异常时调用
     */
    @OnError
    public void onError(Session session, Throwable error) {
        //System.out.println("发生异常");
        error.printStackTrace();
    }

    public static synchronized int getLinkCount() {
        return linkCount;
    }
}
