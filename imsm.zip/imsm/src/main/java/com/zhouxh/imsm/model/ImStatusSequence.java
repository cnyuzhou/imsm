package com.zhouxh.imsm.model;

import java.util.Date;

public class ImStatusSequence {
    private Long sequenceid;

    private Integer imid;

    private Integer statusid;

    private Date logtime;

    public Long getSequenceid() {
        return sequenceid;
    }

    public void setSequenceid(Long sequenceid) {
        this.sequenceid = sequenceid;
    }

    public Integer getImid() {
        return imid;
    }

    public void setImid(Integer imid) {
        this.imid = imid;
    }

    public Integer getStatusid() {
        return statusid;
    }

    public void setStatusid(Integer statusid) {
        this.statusid = statusid;
    }

    public Date getLogtime() {
        return logtime;
    }

    public void setLogtime(Date logtime) {
        this.logtime = logtime;
    }
}